import { Link, useParams } from "wouter";
import { motion } from "framer-motion";
import { MapPin, Clock, ArrowLeft, ArrowRight, AlertCircle, Calendar } from "lucide-react";
import { useGetJob, getGetJobQueryKey } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";

const TYPE_LABELS: Record<string, string> = { "full-time": "Full Time", "part-time": "Part Time", "bank": "Bank" };

export default function JobDetail() {
  const { id } = useParams<{ id: string }>();
  const jobId = Number(id);

  const { data: job, isLoading, isError } = useGetJob(jobId, {
    query: { enabled: !!jobId && !isNaN(jobId), queryKey: getGetJobQueryKey(jobId) }
  });

  if (isLoading) {
    return (
      <Layout>
        <div className="min-h-screen pt-36 pb-20" style={{ backgroundColor: "#05163D" }}>
          <div className="max-w-4xl mx-auto px-5 sm:px-8">
            <div className="h-8 w-40 rounded-lg bg-white/10 animate-pulse mb-8" />
            <div className="h-16 w-2/3 rounded-xl bg-white/10 animate-pulse mb-5" />
            <div className="h-5 w-1/2 rounded-lg bg-white/10 animate-pulse" />
          </div>
        </div>
      </Layout>
    );
  }

  if (isError || !job) {
    return (
      <Layout>
        <section className="min-h-screen flex items-center justify-center" style={{ backgroundColor: "#05163D" }}>
          <div className="text-center px-5">
            <h1 className="text-3xl font-bold text-white mb-4">Job not found</h1>
            <Link href="/jobs" className="text-[#EF2A86] font-semibold">Back to all jobs →</Link>
          </div>
        </section>
      </Layout>
    );
  }

  return (
    <Layout>
      {/* Header */}
      <section style={{ backgroundColor: "#05163D" }} className="pt-36 pb-20">
        <div className="max-w-4xl mx-auto px-5 sm:px-8">
          <Link href="/jobs" className="inline-flex items-center gap-2 text-white/40 hover:text-white text-sm mb-8 transition-colors" data-testid="job-back-link">
            <ArrowLeft size={14} /> All jobs
          </Link>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="flex flex-wrap items-center gap-3 mb-5">
              {job.isUrgent && (
                <span className="inline-flex items-center gap-1.5 text-sm font-bold px-3 py-1.5 rounded-full text-white" style={{ backgroundColor: "#EF2A86" }}>
                  <AlertCircle size={13} /> Urgent Hire
                </span>
              )}
              <span className="inline-block text-sm font-semibold px-3 py-1.5 rounded-full bg-white/10 text-white/70">
                {TYPE_LABELS[job.jobType] || job.jobType}
              </span>
              <span className="inline-block text-sm font-semibold px-3 py-1.5 rounded-full bg-white/10 text-white/70">
                {job.category}
              </span>
            </div>
            <h1 className="text-4xl sm:text-5xl font-bold text-white mb-6">{job.title}</h1>
            <div className="flex flex-wrap gap-6 text-white/60">
              <span className="flex items-center gap-2"><MapPin size={15} /> {job.location}</span>
              <span className="flex items-center gap-2"><Clock size={15} /> {job.salaryRange}</span>
              {job.closingDate && (
                <span className="flex items-center gap-2"><Calendar size={15} /> Closes {new Date(job.closingDate).toLocaleDateString("en-GB", { day: "numeric", month: "long", year: "numeric" })}</span>
              )}
            </div>
          </motion.div>
        </div>
      </section>

      {/* Content */}
      <section className="bg-gray-50">
        <div className="max-w-4xl mx-auto px-5 sm:px-8 py-16">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            <div className="lg:col-span-2 space-y-10">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
                <div className="bg-white rounded-2xl p-8">
                  <h2 className="text-xl font-bold text-[#05163D] mb-5">About the role</h2>
                  <div className="prose prose-sm max-w-none text-gray-600">
                    {job.description.split("\n\n").map((para, i) => (
                      <p key={i} className="leading-relaxed mb-4">{para}</p>
                    ))}
                  </div>
                </div>
              </motion.div>

              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.1 }}>
                <div className="bg-white rounded-2xl p-8">
                  <h2 className="text-xl font-bold text-[#05163D] mb-5">Requirements</h2>
                  <p className="text-gray-600 text-sm leading-relaxed">{job.requirements}</p>
                </div>
              </motion.div>

              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.15 }}>
                <div className="bg-white rounded-2xl p-8">
                  <h2 className="text-xl font-bold text-[#05163D] mb-5">Benefits</h2>
                  <p className="text-gray-600 text-sm leading-relaxed">{job.benefits}</p>
                </div>
              </motion.div>
            </div>

            {/* Sidebar */}
            <div className="space-y-5">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.2 }}>
                <Link
                  href={`/jobs/${job.id}/apply`}
                  className="block w-full text-center px-6 py-4 text-white font-bold rounded-xl hover:opacity-90 transition-opacity"
                  style={{ backgroundColor: "#EF2A86" }}
                  data-testid="job-apply-cta"
                >
                  Apply for this role <ArrowRight size={16} className="inline ml-2" />
                </Link>
              </motion.div>

              <div className="bg-white rounded-2xl p-6 space-y-5">
                <h3 className="text-sm font-bold text-[#05163D]">Role details</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Location</span>
                    <span className="text-[#05163D] font-medium">{job.location}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Type</span>
                    <span className="text-[#05163D] font-medium">{TYPE_LABELS[job.jobType] || job.jobType}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Category</span>
                    <span className="text-[#05163D] font-medium">{job.category}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Salary</span>
                    <span className="text-[#05163D] font-medium text-right max-w-[60%]">{job.salaryRange}</span>
                  </div>
                  {job.closingDate && (
                    <div className="flex justify-between">
                      <span className="text-gray-400">Closing</span>
                      <span className="text-[#05163D] font-medium">{new Date(job.closingDate).toLocaleDateString("en-GB")}</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="bg-[#05163D] rounded-2xl p-6">
                <h3 className="text-sm font-bold text-white mb-2">Questions?</h3>
                <p className="text-white/60 text-xs mb-4">Call our recruitment team directly.</p>
                <a href="tel:03301658880" className="text-[#EF2A86] font-bold text-sm">0330 165 8880</a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
