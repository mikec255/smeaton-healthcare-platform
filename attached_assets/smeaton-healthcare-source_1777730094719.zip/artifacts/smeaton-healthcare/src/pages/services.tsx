import { useRef } from "react";
import { Link } from "wouter";
import { motion, useInView } from "framer-motion";
import { ArrowRight, CheckCircle2, Phone } from "lucide-react";
import { Layout } from "@/components/layout";

const SCRIPT = { fontFamily: "'Dancing Script', cursive" };
const CREAM = "#FDF7F0";

const P108 = "/images/smeaton-108.jpg";
const P124 = "/images/smeaton-124.jpg";
const P117 = "/images/smeaton-117.jpg";
const P131 = "/images/smeaton-131.jpg";

const SERVICES = [
  { slug: "short-visits", num: "01", name: "Short Visits", color: "#EF2A86", img: P108,
    summary: "Flexible care visits from one hour upwards, built entirely around your daily routine and personal preferences.",
    details: ["Personal Care", "Household Support", "Companionship", "Medication Support"] },
  { slug: "supported-living", num: "02", name: "Supported Living", color: "#265597", img: P131,
    summary: "Helping adults live independently in their own home or a supported living setting, with exactly the right level of support.",
    details: ["Independent Living Skills", "Community Participation", "Personal Care", "Life Skills Development"] },
  { slug: "24-7-care", num: "03", name: "24/7 Care", color: "#EF2A86", img: P117,
    summary: "Round-the-clock specialist care for people with complex, high-dependency needs — delivered with consistency and expertise.",
    details: ["Complex Care", "Overnight Support", "Live-In Care", "Clinical Monitoring"] },
  { slug: "enabling", num: "04", name: "Enabling", color: "#265597", img: P124,
    summary: "A care philosophy built around building independence, not creating dependency. We help people achieve their own goals.",
    details: ["Goal-Setting Support", "Community Integration", "Confidence Building", "Skill Development"] },
  { slug: "respite-care", num: "05", name: "Respite Care", color: "#EF2A86", img: P131,
    summary: "Short-term relief for family carers, delivered by our trusted team so you can rest while your loved one is in safe hands.",
    details: ["Planned Respite", "Emergency Cover", "Overnight Respite", "Consistent Carers"] },
];

function FadeIn({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-50px" });
  return (
    <motion.div ref={ref} initial={{ opacity: 0, y: 22 }} animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }} className={className}>
      {children}
    </motion.div>
  );
}

export default function Services() {
  return (
    <Layout>
      {/* Hero */}
      <section className="relative overflow-hidden bg-white" style={{ paddingTop: "76px" }}>
        <div className="absolute left-0 top-0 bottom-0 w-1.5" style={{ backgroundColor: "#EF2A86" }} />
        <div className="max-w-7xl mx-auto px-8 sm:px-14 pt-16 pb-14">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <p className="text-xs font-bold tracking-widest text-[#EF2A86] uppercase mb-5">What we offer</p>
            <h1 className="text-4xl sm:text-5xl font-extrabold text-[#05163D] mb-1 leading-tight tracking-tight">Five services,</h1>
            <div className="mb-5" style={{ ...SCRIPT, fontSize: "clamp(2.5rem, 5.5vw, 4rem)", color: "#EF2A86" }}>one focus — you.</div>
            <p className="text-gray-400 text-lg max-w-2xl leading-relaxed">
              Whether you need a visit once a day or support around the clock, we have the expertise and the right people — across Devon &amp; Cornwall.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Service panels */}
      <section style={{ backgroundColor: CREAM }}>
        <div className="max-w-7xl mx-auto px-5 sm:px-8 py-8">
          {SERVICES.map((s, i) => (
            <FadeIn key={s.slug} delay={0.05}>
              <Link href={`/services/${s.slug}`}
                className="group grid grid-cols-1 lg:grid-cols-2 gap-12 py-14 border-b border-black/06 last:border-0 hover:no-underline items-center"
                data-testid={`service-panel-${s.slug}`}>
                <div className={`flex flex-col justify-center ${i % 2 === 1 ? "lg:order-2 lg:pl-8" : "lg:pr-8"}`}>
                  <div className="flex items-center gap-4 mb-5">
                    <span className="text-6xl font-bold leading-none" style={{ ...SCRIPT, color: s.color, opacity: 0.3 }}>{s.num}</span>
                    <div className="flex-1 h-px opacity-15" style={{ backgroundColor: s.color }} />
                  </div>
                  <h2 className="text-3xl sm:text-4xl font-extrabold text-[#05163D] group-hover:text-[#265597] transition-colors mb-4 tracking-tight">{s.name}</h2>
                  <p className="text-gray-500 leading-relaxed mb-6">{s.summary}</p>
                  <div className="flex flex-wrap gap-2 mb-7">
                    {s.details.map((d) => (
                      <span key={d} className="flex items-center gap-1.5 text-xs font-semibold px-3 py-1.5 rounded-full bg-white text-gray-500 border border-gray-200">
                        <CheckCircle2 size={11} style={{ color: s.color }} /> {d}
                      </span>
                    ))}
                  </div>
                  <span className="inline-flex items-center gap-2 text-sm font-bold transition-all group-hover:gap-3" style={{ color: s.color }}>
                    Find out more <ArrowRight size={15} />
                  </span>
                </div>
                <div className={`hidden lg:block rounded-3xl overflow-hidden shadow-lg ${i % 2 === 1 ? "lg:order-1" : ""}`} style={{ aspectRatio: "4/3" }}>
                  <img src={s.img} alt={s.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                </div>
              </Link>
            </FadeIn>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="relative overflow-hidden py-20" style={{ backgroundColor: "#EF2A86" }}>
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden select-none">
          <span className="text-[160px] font-extrabold text-white opacity-[0.05] leading-none whitespace-nowrap">care</span>
        </div>
        <div className="relative max-w-3xl mx-auto px-5 sm:px-8 text-center">
          <h2 className="text-3xl font-extrabold text-white mb-2 tracking-tight">Need help choosing?</h2>
          <div className="mb-6" style={{ ...SCRIPT, fontSize: "clamp(2.2rem, 5vw, 3.5rem)", color: "rgba(255,255,255,0.9)" }}>We'll guide you through it.</div>
          <p className="text-white/75 mb-10 leading-relaxed">Our team will help you find the right fit — with a free, no-obligation home assessment.</p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/referral"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 font-bold text-lg rounded-xl bg-white hover:scale-105 transition-all"
              style={{ color: "#EF2A86" }}
              data-testid="services-referral-cta">
              Request a Free Assessment <ArrowRight size={18} />
            </Link>
            <a href="tel:03301658880"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 font-bold text-lg rounded-xl text-white hover:bg-white/15 transition-all"
              style={{ border: "2px solid rgba(255,255,255,0.4)" }}>
              <Phone size={16} /> 0330 165 8880
            </a>
          </div>
        </div>
      </section>
    </Layout>
  );
}
