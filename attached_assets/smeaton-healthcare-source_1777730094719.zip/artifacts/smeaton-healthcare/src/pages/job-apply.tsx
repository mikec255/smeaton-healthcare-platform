import { Link, useParams, useLocation } from "wouter";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowLeft, ArrowRight, CheckCircle2 } from "lucide-react";
import { useSubmitApplication, useGetJob, getGetJobQueryKey } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Layout } from "@/components/layout";
import { useState } from "react";

const schema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Valid email required"),
  phone: z.string().min(6, "Phone number is required"),
  coverLetter: z.string().min(50, "Please write at least 50 characters about yourself"),
  experience: z.string().min(20, "Please describe your experience"),
});
type FormData = z.infer<typeof schema>;

function Field({ label, children, error }: { label: string; children: React.ReactNode; error?: string }) {
  return (
    <div>
      <label className="block text-sm font-semibold text-[#05163D] mb-2">{label}</label>
      {children}
      {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
    </div>
  );
}

const inputCls = "w-full px-4 py-3 rounded-xl border border-gray-200 text-sm text-[#05163D] focus:outline-none focus:ring-2 focus:ring-[#265597] transition-shadow bg-white";

export default function JobApply() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [submitted, setSubmitted] = useState(false);
  const jobId = Number(id);

  const { data: job } = useGetJob(jobId, {
    query: { enabled: !!jobId && !isNaN(jobId), queryKey: getGetJobQueryKey(jobId) }
  });

  const { mutate: submitApplication, isPending } = useSubmitApplication();

  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    mode: "onChange",
  });

  const onSubmit = (data: FormData) => {
    submitApplication(
      { data: { ...data, jobId: jobId || null } },
      {
        onSuccess: () => { setSubmitted(true); },
        onError: () => { toast({ title: "Something went wrong", description: "Please try again or call us on 0330 165 8880", variant: "destructive" }); },
      }
    );
  };

  if (submitted) {
    return (
      <Layout>
        <section className="min-h-screen flex items-center justify-center py-36 px-5" style={{ backgroundColor: "#05163D" }}>
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center max-w-md"
          >
            <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6" style={{ backgroundColor: "#EF2A86" }}>
              <CheckCircle2 size={36} className="text-white" />
            </div>
            <h1 className="text-3xl font-bold text-white mb-4">Application sent!</h1>
            <p className="text-white/60 leading-relaxed mb-10">
              Thank you for applying. Our recruitment team will be in touch within 2–3 working days.
              If you have any questions in the meantime, call us on 0330 165 8880.
            </p>
            <Link href="/jobs" className="inline-flex items-center gap-2 px-8 py-4 text-white font-bold rounded-xl hover:opacity-90 transition-opacity" style={{ backgroundColor: "#EF2A86" }} data-testid="apply-success-jobs-link">
              Back to jobs <ArrowRight size={18} />
            </Link>
          </motion.div>
        </section>
      </Layout>
    );
  }

  return (
    <Layout>
      <section style={{ backgroundColor: "#05163D" }} className="pt-36 pb-20">
        <div className="max-w-2xl mx-auto px-5 sm:px-8">
          <Link href={`/jobs/${id}`} className="inline-flex items-center gap-2 text-white/40 hover:text-white text-sm mb-8 transition-colors" data-testid="apply-back-link">
            <ArrowLeft size={14} /> Back to job
          </Link>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <p className="text-[#EF2A86] font-semibold text-sm mb-3">Applying for</p>
            <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2">{job?.title ?? "Care Role"}</h1>
            <p className="text-white/60">{job?.location} · {job?.jobType}</p>
          </motion.div>
        </div>
      </section>

      <section className="bg-gray-50 py-16">
        <div className="max-w-2xl mx-auto px-5 sm:px-8">
          <motion.form
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            onSubmit={handleSubmit(onSubmit)}
            className="bg-white rounded-3xl p-8 sm:p-10 space-y-6"
            noValidate
          >
            <h2 className="text-xl font-bold text-[#05163D] mb-2">Your details</h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <Field label="First name" error={errors.firstName?.message}>
                <input {...register("firstName")} className={inputCls} placeholder="Jane" data-testid="apply-first-name" />
              </Field>
              <Field label="Last name" error={errors.lastName?.message}>
                <input {...register("lastName")} className={inputCls} placeholder="Smith" data-testid="apply-last-name" />
              </Field>
            </div>

            <Field label="Email address" error={errors.email?.message}>
              <input {...register("email")} type="email" className={inputCls} placeholder="jane@example.com" data-testid="apply-email" />
            </Field>

            <Field label="Phone number" error={errors.phone?.message}>
              <input {...register("phone")} type="tel" className={inputCls} placeholder="07700 000000" data-testid="apply-phone" />
            </Field>

            <Field label="Tell us about your experience" error={errors.experience?.message}>
              <textarea
                {...register("experience")}
                rows={4}
                className={inputCls}
                placeholder="Briefly describe your care experience, qualifications, or relevant background..."
                data-testid="apply-experience"
              />
            </Field>

            <Field label="Why do you want to work at Smeaton?" error={errors.coverLetter?.message}>
              <textarea
                {...register("coverLetter")}
                rows={5}
                className={inputCls}
                placeholder="Tell us what draws you to care work and why Smeaton Healthcare..."
                data-testid="apply-cover-letter"
              />
            </Field>

            <button
              type="submit"
              disabled={isPending}
              className="w-full py-4 text-white font-bold text-base rounded-xl transition-opacity hover:opacity-90 disabled:opacity-60 flex items-center justify-center gap-2"
              style={{ backgroundColor: "#EF2A86" }}
              data-testid="apply-submit"
            >
              {isPending ? "Submitting..." : <>Submit Application <ArrowRight size={18} /></>}
            </button>

            <p className="text-center text-xs text-gray-400">
              By submitting, you agree that we may contact you about this and similar roles.
            </p>
          </motion.form>
        </div>
      </section>
    </Layout>
  );
}
