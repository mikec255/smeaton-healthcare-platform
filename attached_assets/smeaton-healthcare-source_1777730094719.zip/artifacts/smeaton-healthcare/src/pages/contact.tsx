import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Phone, Mail, MapPin, Clock, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import { Layout } from "@/components/layout";

const SCRIPT = { fontFamily: "'Dancing Script', cursive" };

const OFFICES = [
  { name: "Plymouth Office", address: "Smeaton Healthcare, Plymouth, Devon", phone: "0330 165 8880", email: "info@smeatonhealthcare.co.uk", cqc: "CQC Rated Good — April 2022", color: "#EF2A86" },
  { name: "Cornwall Office", address: "Smeaton Healthcare, Cornwall", phone: "0330 165 8880", email: "info@smeatonhealthcare.co.uk", cqc: "CQC Rated Good — January 2022", color: "#265597" },
];

function FadeIn({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-50px" });
  return (
    <motion.div ref={ref} initial={{ opacity: 0, y: 22 }} animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }} className={className}>
      {children}
    </motion.div>
  );
}

export default function Contact() {
  return (
    <Layout>
      {/* Hero — light */}
      <section className="relative overflow-hidden bg-white" style={{ paddingTop: "76px" }}>
        <div className="absolute -top-10 -right-10 w-[350px] h-[350px] rounded-full pointer-events-none"
          style={{ background: "radial-gradient(circle, rgba(38,85,151,0.06) 0%, transparent 70%)" }} />
        <div className="max-w-7xl mx-auto px-5 sm:px-8 pt-16 pb-14">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <p className="text-xs font-bold tracking-widest text-[#EF2A86] uppercase mb-5">Get in touch</p>
            <h1 className="text-4xl sm:text-5xl font-bold text-[#05163D] mb-1 leading-tight">We'd love to</h1>
            <h1 className="text-5xl sm:text-6xl mb-5" style={{ ...SCRIPT, color: "#EF2A86" }}>hear from you.</h1>
            <p className="text-gray-500 text-lg max-w-xl leading-relaxed">
              Whether you have a question about our services, want to arrange a free assessment, or are interested in joining our team — we're here.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Contact cards */}
      <section style={{ backgroundColor: "#F4F6FA" }} className="py-20">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            {OFFICES.map((office, i) => (
              <FadeIn key={i} delay={i * 0.1}>
                <div className="bg-white rounded-3xl p-8 h-full border-2 border-gray-100 hover:border-gray-200 transition-all">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="w-2 h-8 rounded-full" style={{ backgroundColor: office.color }} />
                    <h2 className="text-xl font-bold text-[#05163D]">{office.name}</h2>
                  </div>
                  <div className="space-y-5">
                    {[
                      { Icon: MapPin, label: "Address", value: office.address, href: undefined },
                      { Icon: Phone, label: "Phone", value: office.phone, href: `tel:${office.phone.replace(/\s/g, "")}` },
                      { Icon: Mail, label: "Email", value: office.email, href: `mailto:${office.email}` },
                    ].map(({ Icon, label, value, href }) => (
                      <div key={label} className="flex items-start gap-4">
                        <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ backgroundColor: `${office.color}15` }}>
                          <Icon size={16} style={{ color: office.color }} />
                        </div>
                        <div>
                          <p className="text-xs text-gray-400 font-semibold uppercase tracking-wider mb-1">{label}</p>
                          {href ? (
                            <a href={href} className="text-sm font-bold transition-opacity hover:opacity-70" style={{ color: office.color }}>{value}</a>
                          ) : (
                            <p className="text-sm font-medium text-[#05163D]">{value}</p>
                          )}
                        </div>
                      </div>
                    ))}
                    <div className="pt-5 border-t border-gray-100 flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: office.color }} />
                      <p className="text-xs font-bold" style={{ color: office.color }}>{office.cqc}</p>
                    </div>
                  </div>
                </div>
              </FadeIn>
            ))}
          </div>

          <FadeIn delay={0.2}>
            <div className="bg-white rounded-3xl p-8 border border-gray-100">
              <div className="flex flex-col sm:flex-row items-start gap-6">
                <div className="w-12 h-12 rounded-2xl flex items-center justify-center shrink-0" style={{ backgroundColor: "#EF2A8615" }}>
                  <Clock size={20} style={{ color: "#EF2A86" }} />
                </div>
                <div className="flex-1">
                  <h2 className="text-xl font-bold text-[#05163D] mb-5">Office hours</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {[
                      { day: "Monday – Friday", hours: "8:00am – 6:00pm", highlight: false },
                      { day: "Saturday", hours: "9:00am – 4:00pm", highlight: false },
                      { day: "Sunday", hours: "On-call only", highlight: false },
                      { day: "Emergencies", hours: "24/7 on-call", highlight: true },
                    ].map((h) => (
                      <div key={h.day} className={`flex justify-between items-center px-4 py-3 rounded-xl ${h.highlight ? "" : "bg-gray-50"}`}
                        style={h.highlight ? { backgroundColor: "#EF2A8612" } : {}}>
                        <span className="text-sm text-gray-400">{h.day}</span>
                        <span className="text-sm font-bold" style={h.highlight ? { color: "#EF2A86" } : { color: "#05163D" }}>{h.hours}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* Quick links — light version */}
      <section className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <FadeIn className="mb-8">
            <h2 className="text-2xl font-bold text-[#05163D] mb-1">Other ways we can help</h2>
            <p className="text-gray-400 text-sm">Quick links to our most popular pages</p>
          </FadeIn>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              { href: "/referral", label: "Request a Free Assessment", desc: "Arrange a no-obligation care visit", color: "#EF2A86" },
              { href: "/jobs", label: "View Open Roles", desc: "Join our care team in Devon & Cornwall", color: "#265597" },
              { href: "/feedback", label: "Leave Feedback", desc: "Help us improve our services", color: "#05163D" },
            ].map((item) => (
              <Link key={item.href} href={item.href}
                className="group flex items-center justify-between p-6 rounded-2xl border-2 border-gray-100 hover:border-[#EF2A86] bg-gray-50 hover:bg-white transition-all"
                data-testid={`contact-quick-${item.href.replace("/", "")}`}>
                <div>
                  <h3 className="font-bold text-[#05163D] mb-1">{item.label}</h3>
                  <p className="text-gray-400 text-sm">{item.desc}</p>
                </div>
                <ArrowRight size={20} className="text-gray-300 group-hover:text-[#EF2A86] group-hover:translate-x-1 transition-all shrink-0 ml-4" />
              </Link>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
}
