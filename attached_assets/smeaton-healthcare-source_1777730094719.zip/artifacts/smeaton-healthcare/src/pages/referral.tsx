import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowRight, CheckCircle2 } from "lucide-react";
import { Link } from "wouter";
import { useSubmitReferral } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Layout } from "@/components/layout";
import { useState } from "react";

const SERVICES = ["Short Visits", "Supported Living", "24/7 Care", "Enabling", "Respite Care", "Not sure — please advise"];

const schema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  email: z.string().email("Valid email required"),
  phone: z.string().min(6, "Phone number is required"),
  serviceRequired: z.string().min(1, "Please select a service"),
  additionalInfo: z.string().optional(),
});
type FormData = z.infer<typeof schema>;

function Field({ label, children, error }: { label: string; children: React.ReactNode; error?: string }) {
  return (
    <div>
      <label className="block text-sm font-semibold text-[#05163D] mb-2">{label}</label>
      {children}
      {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
    </div>
  );
}

const inputCls = "w-full px-4 py-3 rounded-xl border border-gray-200 text-sm text-[#05163D] focus:outline-none focus:ring-2 focus:ring-[#265597] transition-shadow bg-white";

export default function Referral() {
  const { toast } = useToast();
  const [submitted, setSubmitted] = useState(false);
  const { mutate: submitReferral, isPending } = useSubmitReferral();

  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    mode: "onChange",
  });

  const onSubmit = (data: FormData) => {
    submitReferral(
      { data },
      {
        onSuccess: () => setSubmitted(true),
        onError: () => toast({ title: "Something went wrong", description: "Please try again or call us on 0330 165 8880", variant: "destructive" }),
      }
    );
  };

  if (submitted) {
    return (
      <Layout>
        <section className="min-h-screen flex items-center justify-center py-36 px-5" style={{ backgroundColor: "#05163D" }}>
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="text-center max-w-md">
            <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6" style={{ backgroundColor: "#EF2A86" }}>
              <CheckCircle2 size={36} className="text-white" />
            </div>
            <h1 className="text-3xl font-bold text-white mb-4">Referral received</h1>
            <p className="text-white/60 leading-relaxed mb-10">
              Thank you for getting in touch. A member of our team will contact you within 1–2 working days to arrange a free assessment at a time that suits you.
            </p>
            <Link href="/" className="inline-flex items-center gap-2 px-8 py-4 text-white font-bold rounded-xl hover:opacity-90 transition-opacity" style={{ backgroundColor: "#EF2A86" }} data-testid="referral-success-home-link">
              Back to home <ArrowRight size={18} />
            </Link>
          </motion.div>
        </section>
      </Layout>
    );
  }

  return (
    <Layout>
      <section style={{ backgroundColor: "#05163D" }} className="pt-36 pb-20">
        <div className="max-w-2xl mx-auto px-5 sm:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="flex items-center gap-3 mb-6">
              <div className="h-px w-10 bg-[#EF2A86]" />
              <span className="text-sm font-medium tracking-widest text-white/60 uppercase">Get started</span>
            </div>
            <h1 className="text-4xl sm:text-5xl font-bold text-white mb-5">Make a Referral</h1>
            <p className="text-white/60 leading-relaxed">
              Fill in the form below and our team will be in touch to arrange a free, no-obligation care assessment. No waiting lists, no pressure.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="bg-gray-50 py-16">
        <div className="max-w-2xl mx-auto px-5 sm:px-8">
          <motion.form
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            onSubmit={handleSubmit(onSubmit)}
            className="bg-white rounded-3xl p-8 sm:p-10 space-y-6"
            noValidate
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <Field label="First name" error={errors.firstName?.message}>
                <input {...register("firstName")} className={inputCls} placeholder="Jane" data-testid="referral-first-name" />
              </Field>
              <Field label="Last name" error={errors.lastName?.message}>
                <input {...register("lastName")} className={inputCls} placeholder="Smith" data-testid="referral-last-name" />
              </Field>
            </div>

            <Field label="Email address" error={errors.email?.message}>
              <input {...register("email")} type="email" className={inputCls} placeholder="jane@example.com" data-testid="referral-email" />
            </Field>

            <Field label="Phone number" error={errors.phone?.message}>
              <input {...register("phone")} type="tel" className={inputCls} placeholder="07700 000000" data-testid="referral-phone" />
            </Field>

            <Field label="Service required" error={errors.serviceRequired?.message}>
              <select {...register("serviceRequired")} className={inputCls} data-testid="referral-service">
                <option value="">Select a service...</option>
                {SERVICES.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </Field>

            <Field label="Additional information (optional)">
              <textarea
                {...register("additionalInfo")}
                rows={4}
                className={inputCls}
                placeholder="Tell us anything that would help us understand the care needed..."
                data-testid="referral-additional-info"
              />
            </Field>

            <button
              type="submit"
              disabled={isPending}
              className="w-full py-4 text-white font-bold text-base rounded-xl transition-opacity hover:opacity-90 disabled:opacity-60 flex items-center justify-center gap-2"
              style={{ backgroundColor: "#EF2A86" }}
              data-testid="referral-submit"
            >
              {isPending ? "Submitting..." : <>Send Referral <ArrowRight size={18} /></>}
            </button>

            <p className="text-center text-xs text-gray-400">
              Or call us directly: <a href="tel:03301658880" className="font-semibold text-[#265597]">0330 165 8880</a>
            </p>
          </motion.form>
        </div>
      </section>
    </Layout>
  );
}
