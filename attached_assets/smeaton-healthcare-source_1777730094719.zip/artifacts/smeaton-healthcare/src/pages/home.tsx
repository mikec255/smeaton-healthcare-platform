import { useRef, useEffect } from "react";
import { Link } from "wouter";
import { motion, useInView } from "framer-motion";
import { ArrowRight, CheckCircle2, Phone, ShieldCheck, Award, Clock, Heart } from "lucide-react";
import { Layout } from "@/components/layout";

const SCRIPT = { fontFamily: "'Dancing Script', cursive" };
const CREAM = "#FDF7F0";

const P108 = "/images/smeaton-108.jpg";
const P124 = "/images/smeaton-124.jpg";
const P117 = "/images/smeaton-117.jpg";
const P131 = "/images/smeaton-131.jpg";

const SERVICES = [
  { num: "01", name: "Short Visits", slug: "short-visits", desc: "Personal care, medication, meals and companionship — built around your day, not ours.", color: "#EF2A86" },
  { num: "02", name: "Supported Living", slug: "supported-living", desc: "Specialist support helping adults live independently and confidently.", color: "#265597" },
  { num: "03", name: "24/7 Care", slug: "24-7-care", desc: "Around-the-clock care for complex needs — consistent, trained, reliable.", color: "#EF2A86" },
  { num: "04", name: "Enabling", slug: "enabling", desc: "Building independence rather than dependency. Care that empowers.", color: "#265597" },
  { num: "05", name: "Respite Care", slug: "respite-care", desc: "Trusted short-term cover so family carers can rest and recharge.", color: "#EF2A86" },
];

const TESTIMONIALS = [
  { quote: "The carers from Smeaton are wonderful — Mum knows them by name and actually looks forward to their visits.", name: "Sarah T.", relation: "Daughter of service user, Plymouth" },
  { quote: "After years of struggling on my own, having the right support has genuinely given me my life back.", name: "Brian M.", relation: "Service user, Cornwall" },
  { quote: "We tried another agency first. The difference with Smeaton was immediate — consistent carers, real warmth.", name: "Rachel K.", relation: "Family carer, Devon" },
];

const COVERAGE = ["Plymouth","Saltash","Liskeard","Tavistock","Ivybridge","Kingsbridge","Totnes","Truro","Falmouth","Penzance","Newquay","Bodmin","Camborne","Redruth","St Austell","Wadebridge","Launceston","Helston","Hayle","St Ives"];


function FadeIn({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-50px" });
  return (
    <motion.div ref={ref} initial={{ opacity: 0, y: 28 }} animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.65, delay, ease: [0.22, 1, 0.36, 1] }} className={className}>
      {children}
    </motion.div>
  );
}

function Ticker() {
  return (
    <div style={{ backgroundColor: "#EF2A86", padding: "15px 0" }}>
      <div className="pl-16 sm:pl-24 pr-5 flex items-center justify-start flex-nowrap gap-x-7 sm:gap-x-9">

        {/* Google Reviews */}
        <span className="inline-flex items-center gap-2 shrink-0">
          <img src="/images/google-logo.png" alt="Google" style={{ height: 17, width: "auto", filter: "brightness(0) invert(1)" }} />
          <span className="text-yellow-200 text-sm leading-none">★★★★★</span>
          <span className="text-white font-bold text-sm">4.9</span>
        </span>

        <span className="text-white/30 shrink-0 text-base">|</span>

        {/* Trustpilot */}
        <span className="inline-flex items-center gap-2 shrink-0">
          <img src="/images/trustpilot-white.svg" alt="Trustpilot" style={{ height: 20, width: "auto" }} />
          <span className="text-white/90 text-sm font-medium hidden xs:inline">Rated Excellent</span>
        </span>

        <span className="text-white/30 shrink-0 text-base">|</span>

        {/* Care within 24 hours — sm+ only */}
        <span className="hidden sm:inline-flex items-center gap-2 shrink-0">
          <span className="text-white/90 text-sm font-medium whitespace-nowrap">♥ Care within 24 hours</span>
        </span>

        <span className="text-white/30 hidden sm:inline shrink-0 text-base">|</span>

        {/* CQC — desktop only */}
        <span className="hidden sm:inline-flex items-center gap-2 shrink-0">
          <img src="/images/cqc-logo.svg" alt="CQC" style={{ height: 19, width: "auto" }} />
          <span className="text-white/90 text-sm font-medium">Rated Good</span>
        </span>

        <span className="text-white/30 hidden sm:inline shrink-0 text-base">|</span>

        {/* NHS — desktop only */}
        <span className="hidden sm:inline-flex items-center gap-2 shrink-0">
          <span className="bg-white text-xs font-black px-2 py-0.5 rounded" style={{ color: "#005EB8" }}>NHS</span>
          <span className="text-white/90 text-sm font-medium">Approved Provider</span>
        </span>

        <span className="text-white/30 hidden sm:inline shrink-0 text-base">|</span>

        {/* Competitive rates — desktop only */}
        <span className="hidden sm:inline-flex items-center gap-2 shrink-0">
          <span className="text-white/90 text-sm font-medium whitespace-nowrap">★ Competitive rates</span>
        </span>

      </div>
    </div>
  );
}

export default function Home() {
  useEffect(() => { document.title = "Home Care Devon & Cornwall | Smeaton Healthcare | CQC Rated Good"; }, []);

  return (
    <Layout>
      {/* ═══════════════════════════════════════════
          HERO — split: cream text left, photo right
      ═══════════════════════════════════════════ */}
      {/* Trust ticker — sits directly below the navbar, home page only */}
      <div style={{ paddingTop: "96px" }}>
        <Ticker />
      </div>

      <section className="relative overflow-hidden" style={{ backgroundColor: CREAM, minHeight: "92vh" }}>


        <div className="grid grid-cols-1 lg:grid-cols-[55%_45%]" style={{ minHeight: "88vh" }}>

          {/* LEFT — cream bg, navy text */}
          <div className="flex flex-col justify-start pt-14 sm:pt-20 pb-16 pl-16 sm:pl-24 pr-8">
            <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 self-start rounded-full px-4 py-1.5 mb-10"
              style={{ backgroundColor: "#EF2A8618" }}>
              <ShieldCheck size={13} style={{ color: "#EF2A86" }} />
              <span className="text-xs font-bold tracking-widest uppercase" style={{ color: "#EF2A86" }}>CQC Rated Good · Since 2019</span>
            </motion.div>

            {/* "Home care that" — all on ONE line, navy */}
            <motion.span initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
              className="block font-extrabold leading-[0.92] tracking-tight whitespace-nowrap"
              style={{ fontSize: "clamp(28px, 3.8vw, 58px)", color: "#265597" }}>
              Home care that
            </motion.span>

            {/* Script line — pink */}
            <motion.span initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
              className="block leading-[1.05]"
              style={{ ...SCRIPT, fontSize: "clamp(40px, 5.2vw, 80px)", color: "#EF2A86" }}>
              feels like it should.
            </motion.span>

            <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.6, delay: 0.38 }}
              className="text-gray-500 text-base sm:text-lg leading-relaxed max-w-sm mt-7 mb-10">
              Trusted by families across Devon &amp; Cornwall since 2019. CQC-rated Good, NHS approved.
            </motion.p>

            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.48 }}
              className="flex flex-col sm:flex-row gap-3 mb-10">
              <Link href="/referral"
                className="inline-flex items-center justify-center gap-2 px-7 py-4 text-white font-bold rounded-xl transition-all hover:scale-105"
                style={{ backgroundColor: "#EF2A86", boxShadow: "0 12px 40px rgba(239,42,134,0.35)" }}
                data-testid="hero-referral-cta">
                Free Assessment <ArrowRight size={17} />
              </Link>
              <a href="tel:03301658880"
                className="inline-flex items-center justify-center gap-2 px-7 py-4 font-semibold rounded-xl text-[#05163D] transition-all hover:bg-black/5 border-2 border-[#05163D]/15">
                <Phone size={16} /> 0330 165 8880
              </a>
            </motion.div>

            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.64 }}
              className="flex flex-wrap gap-6 pt-8 border-t border-black/08">
              {[{ icon: ShieldCheck, t: "CQC Rated Good" }, { icon: Award, t: "NHS Approved" }, { icon: Clock, t: "Est. 2019" }].map(({ icon: Icon, t }) => (
                <span key={t} className="flex items-center gap-2 text-xs font-bold text-gray-400 uppercase tracking-wider">
                  <Icon size={14} style={{ color: "#EF2A86" }} /> {t}
                </span>
              ))}
            </motion.div>
          </div>

          {/* RIGHT — full-bleed branded photo, blending into cream on the left edge */}
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.9, delay: 0.1 }}
            className="hidden lg:block relative" style={{ marginLeft: "-80px" }}>
            <img src={P124} alt="Smeaton carer and client gardening" className="absolute inset-0 w-full h-full object-cover" />
            {/* Gradient fade — covers the seam and blends photo into cream */}
            <div className="absolute inset-0 pointer-events-none"
              style={{ background: `linear-gradient(to right, ${CREAM} 0%, transparent 22%)` }} />
            {/* Floating CQC card */}
            <div className="absolute bottom-6 right-6 bg-white rounded-2xl px-5 py-4 shadow-2xl">
              <div className="flex gap-0.5 mb-1.5">
                {[...Array(5)].map((_, i) => <svg key={i} width="12" height="12" viewBox="0 0 24 24" fill="#EF2A86"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" /></svg>)}
              </div>
              <p className="text-xs font-extrabold text-[#05163D]">CQC Rated Good</p>
              <p className="text-xs text-gray-400 mt-0.5">Plymouth &amp; Cornwall</p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ═══════════════════════════════════════════
          ABOUT — cream bg
      ═══════════════════════════════════════════ */}
      <section style={{ backgroundColor: "white" }} className="py-20 sm:py-28">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-center">
            <FadeIn>
              <p className="text-xs font-bold tracking-widest text-[#EF2A86] uppercase mb-5">Who we are</p>
              <h2 className="text-4xl sm:text-5xl font-extrabold text-[#05163D] leading-tight mb-2 tracking-tight">Your family deserves</h2>
              <div className="mb-8" style={{ ...SCRIPT, fontSize: "clamp(2rem, 4vw, 3.2rem)", color: "#EF2A86", lineHeight: 1.1 }}>
                more than a rota and a stranger.
              </div>
              <p className="text-gray-500 text-base leading-relaxed mb-6">
                When you're looking for care for someone you love, you're not looking for ticked boxes. You're looking for people you can trust — who will show up, every time, and treat your family member like a person, not a task. That's what we've built since 2019.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-8">
                {["Consistent carers — familiar faces", "CQC Rated Good — both offices", "No waiting lists for private clients", "Transparent pricing — no surprises"].map((item) => (
                  <span key={item} className="flex items-start gap-2 text-sm text-gray-600">
                    <CheckCircle2 size={14} style={{ color: "#EF2A86" }} className="shrink-0 mt-0.5" /> {item}
                  </span>
                ))}
              </div>
              <Link href="/about" className="inline-flex items-center gap-2 text-sm font-bold text-[#05163D] border-b-2 border-[#EF2A86] pb-0.5 hover:gap-3 transition-all" data-testid="home-about-link">
                Our story <ArrowRight size={15} />
              </Link>
            </FadeIn>

            <FadeIn delay={0.1}>
              <div className="relative">
                <div className="rounded-3xl overflow-hidden aspect-[3/4] shadow-2xl">
                  <img src={P131} alt="Smeaton carer supporting client in garden" className="w-full h-full object-cover" />
                </div>
                <div className="absolute -bottom-5 -left-5 bg-white rounded-2xl p-5 shadow-xl border border-gray-100">
                  <div className="text-3xl font-extrabold text-[#05163D] mb-0.5">Since 2019</div>
                  <div className="text-sm text-gray-400">Serving Devon &amp; Cornwall</div>
                </div>
                <div className="absolute -top-4 -right-4 w-20 h-20 rounded-2xl flex flex-col items-center justify-center text-white" style={{ backgroundColor: "#EF2A86" }}>
                  <div className="text-2xl font-extrabold leading-none">7+</div>
                  <div className="text-xs font-semibold opacity-80">Years</div>
                </div>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* ═══════════════════════════════════════════
          SERVICES — white
      ═══════════════════════════════════════════ */}
      <section className="bg-white py-20 sm:py-28">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <FadeIn className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-14">
            <div>
              <p className="text-xs font-bold tracking-widest text-[#EF2A86] uppercase mb-3">What we offer</p>
              <h2 className="text-4xl sm:text-5xl font-extrabold text-[#05163D] tracking-tight">Five ways we</h2>
              <div style={{ ...SCRIPT, fontSize: "clamp(2.5rem, 5vw, 3.8rem)", color: "#EF2A86" }}>can help.</div>
            </div>
            <Link href="/services" className="flex items-center gap-2 text-sm font-bold text-[#05163D] border-b-2 border-[#05163D]/15 pb-0.5 hover:gap-3 transition-all shrink-0" data-testid="home-all-services-link">
              All services <ArrowRight size={15} />
            </Link>
          </FadeIn>

          <div className="space-y-1">
            {SERVICES.map((s, i) => (
              <FadeIn key={s.slug} delay={i * 0.06}>
                <Link href={`/services/${s.slug}`}
                  className="group flex items-center gap-6 sm:gap-10 py-5 px-6 sm:px-8 rounded-2xl transition-all hover:shadow-md"
                  style={{ backgroundColor: CREAM }}
                  data-testid={`service-row-${s.slug}`}>
                  <span className="text-4xl sm:text-5xl font-bold shrink-0 w-14 text-right leading-none"
                    style={{ ...SCRIPT, color: s.color, opacity: 0.45 }}>{s.num}</span>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg sm:text-xl font-extrabold text-[#05163D] group-hover:text-[#265597] transition-colors mb-1 tracking-tight">{s.name}</h3>
                    <p className="text-gray-400 text-sm leading-relaxed">{s.desc}</p>
                  </div>
                  <ArrowRight size={16} className="hidden sm:block transition-all group-hover:translate-x-1 text-gray-300 group-hover:text-[#EF2A86] shrink-0" />
                </Link>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════════════════════════════════════════
          FULL-BLEED PHOTO QUOTE
      ═══════════════════════════════════════════ */}
      <section className="relative overflow-hidden" style={{ minHeight: "520px" }}>
        <div className="absolute inset-0">
          <img src={P108} alt="Smeaton carer with client" className="w-full h-full object-cover object-top" />
          <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, rgba(5,22,61,0.88) 0%, rgba(5,22,61,0.5) 60%, transparent 100%)" }} />
        </div>
        <div className="relative max-w-7xl mx-auto px-5 sm:px-8 py-24 sm:py-32 flex items-end" style={{ minHeight: "520px" }}>
          <FadeIn>
            <div className="max-w-2xl">
              <div className="text-[90px] select-none mb-1"
                style={{ color: "rgba(239,42,134,0.4)", fontFamily: "Georgia, serif", lineHeight: 0.7, fontWeight: 700 }}>"</div>
              <p className="text-2xl sm:text-3xl font-bold text-white leading-snug mb-6 italic">
                "The carers from Smeaton are wonderful — Mum knows them by name and actually looks forward to their visits. That means everything."
              </p>
              <p className="text-white/60 font-semibold text-sm">Sarah T. · Daughter of service user, Plymouth</p>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* ═══════════════════════════════════════════
          PRIVATE CLIENTS — cream
      ═══════════════════════════════════════════ */}
      <section style={{ backgroundColor: CREAM }} className="py-20 sm:py-28">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-center">
            <FadeIn>
              <p className="text-xs font-bold tracking-widest text-[#EF2A86] uppercase mb-5">Self-funded care</p>
              <h2 className="text-4xl sm:text-5xl font-extrabold text-[#05163D] leading-tight mb-2 tracking-tight">Funding your own</h2>
              <div className="mb-8" style={{ ...SCRIPT, fontSize: "clamp(2rem, 4vw, 3.2rem)", color: "#EF2A86", lineHeight: 1.1 }}>
                care, your way.
              </div>
              <p className="text-gray-500 text-base leading-relaxed mb-8">
                Many families choose to fund care privately — no waiting lists, no rigid rotas. We welcome private clients and can usually begin within days of your assessment.
              </p>
              <div className="grid grid-cols-2 gap-3 mb-10">
                {[
                  { num: "No", label: "waiting lists" },
                  { num: "Same", label: "carers every visit" },
                  { num: "Your", label: "hours, your routine" },
                  { num: "Clear", label: "transparent pricing" },
                ].map((s) => (
                  <div key={s.label} className="flex items-center gap-4 p-4 rounded-xl bg-white">
                    <div className="text-lg font-extrabold" style={{ color: "#EF2A86" }}>{s.num}</div>
                    <div className="text-sm font-semibold text-[#05163D]">{s.label}</div>
                  </div>
                ))}
              </div>
              <Link href="/referral"
                className="inline-flex items-center gap-2 px-7 py-4 text-white font-bold rounded-xl hover:scale-105 transition-all"
                style={{ backgroundColor: "#EF2A86", boxShadow: "0 12px 40px rgba(239,42,134,0.28)" }}
                data-testid="home-private-cta">
                Talk to us about your options <ArrowRight size={16} />
              </Link>
            </FadeIn>

            <FadeIn delay={0.1}>
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2 rounded-3xl overflow-hidden shadow-md" style={{ aspectRatio: "16/8" }}>
                  <img src={P117} alt="Smeaton carer arriving at client home" className="w-full h-full object-cover object-top" />
                </div>
                <div className="rounded-2xl p-7 text-white text-center" style={{ backgroundColor: "#EF2A86" }}>
                  <div className="text-4xl font-extrabold mb-1">Good</div>
                  <div className="text-xs text-white/70 font-bold uppercase tracking-widest">CQC Rating</div>
                </div>
                <div className="rounded-2xl p-7 text-center bg-white">
                  <div className="text-4xl font-extrabold text-[#05163D] mb-1">7+</div>
                  <div className="text-xs text-gray-400 font-bold uppercase tracking-widest">Years</div>
                </div>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* ═══════════════════════════════════════════
          TESTIMONIALS — white
      ═══════════════════════════════════════════ */}
      <section className="bg-white py-20 sm:py-28">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <FadeIn className="mb-14">
            <p className="text-xs font-bold tracking-widest text-[#EF2A86] uppercase mb-3">In their own words</p>
            <h2 className="text-4xl sm:text-5xl font-extrabold text-[#05163D] tracking-tight">Real people.</h2>
            <div style={{ ...SCRIPT, fontSize: "clamp(2.5rem, 5vw, 3.8rem)", color: "#265597" }}>Real stories.</div>
          </FadeIn>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {TESTIMONIALS.map((t, i) => (
              <FadeIn key={i} delay={i * 0.08}>
                <div className={`rounded-3xl p-8 h-full flex flex-col ${i === 1 ? "bg-[#05163D]" : ""}`}
                  style={i !== 1 ? { backgroundColor: CREAM, border: "2px solid rgba(0,0,0,0.04)" } : {}}>
                  <div className="text-[80px] leading-none select-none"
                    style={{ color: i === 1 ? "rgba(239,42,134,0.2)" : "rgba(239,42,134,0.12)", fontFamily: "Georgia, serif", lineHeight: 0.75 }}>"</div>
                  <p className={`text-base leading-relaxed flex-1 italic mt-4 ${i === 1 ? "text-white/80" : "text-gray-600"}`}>{t.quote}</p>
                  <div className={`mt-6 pt-5 border-t ${i === 1 ? "border-white/10" : "border-black/06"}`}>
                    <p className={`text-sm font-extrabold ${i === 1 ? "text-white" : "text-[#05163D]"}`}>{t.name}</p>
                    <p className={`text-xs mt-0.5 ${i === 1 ? "text-white/40" : "text-gray-400"}`}>{t.relation}</p>
                  </div>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════════════════════════════════════════
          COVERAGE — cream
      ═══════════════════════════════════════════ */}
      <section style={{ backgroundColor: CREAM }} className="py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <FadeIn className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-start">
            <div>
              <p className="text-xs font-bold tracking-widest text-[#EF2A86] uppercase mb-3">Where we work</p>
              <h2 className="text-3xl font-extrabold text-[#05163D] tracking-tight mb-1">Home care across</h2>
              <div style={{ ...SCRIPT, fontSize: "clamp(2rem, 4vw, 3rem)", color: "#265597" }}>Devon &amp; Cornwall</div>
              <p className="text-gray-400 text-sm leading-relaxed mt-4">
                Don't see your town? <a href="tel:03301658880" className="font-bold hover:underline" style={{ color: "#EF2A86" }}>Call us</a> — we're always expanding.
              </p>
            </div>
            <div className="lg:col-span-2 flex flex-wrap gap-2">
              {COVERAGE.map((town) => (
                <span key={town} className="px-4 py-2 rounded-full text-sm font-semibold text-[#05163D] border-2 border-[#05163D]/10 hover:border-[#EF2A86] hover:text-[#EF2A86] cursor-default transition-all bg-white">
                  {town}
                </span>
              ))}
            </div>
          </FadeIn>
        </div>
      </section>

      {/* ═══════════════════════════════════════════
          FINAL CTA — pink
      ═══════════════════════════════════════════ */}
      <section className="relative overflow-hidden py-24" style={{ backgroundColor: "#EF2A86" }}>
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none overflow-hidden select-none">
          <span className="text-[180px] font-extrabold text-white opacity-[0.05] leading-none tracking-tight whitespace-nowrap">Smeaton</span>
        </div>
        <div className="absolute -top-16 -right-16 w-72 h-72 rounded-full bg-white opacity-[0.06] pointer-events-none" />
        <div className="relative max-w-4xl mx-auto px-5 sm:px-8 text-center">
          <FadeIn>
            <div className="inline-flex items-center gap-2 mb-8 rounded-full px-4 py-1.5 bg-white/10">
              <Heart size={13} className="text-white" />
              <span className="text-xs font-bold tracking-widest uppercase text-white/80">Family-focused home care</span>
            </div>
            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white mb-2 tracking-tight">Ready to talk?</h2>
            <div className="mb-8" style={{ ...SCRIPT, fontSize: "clamp(2.8rem, 6vw, 5rem)", color: "rgba(255,255,255,0.9)" }}>We'd love to help.</div>
            <p className="text-white/75 mb-12 text-lg leading-relaxed max-w-xl mx-auto">
              Call us or request a free home assessment. No pressure. No obligation. Just an honest conversation about what you need.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4">
              <Link href="/referral"
                className="inline-flex items-center justify-center gap-2 px-9 py-5 font-extrabold text-lg rounded-xl bg-white hover:scale-105 transition-all"
                style={{ color: "#EF2A86" }}
                data-testid="home-referral-cta">
                Request a Free Assessment <ArrowRight size={18} />
              </Link>
              <a href="tel:03301658880"
                className="inline-flex items-center justify-center gap-2 px-9 py-5 font-extrabold text-lg rounded-xl text-white hover:bg-white/15 transition-all"
                style={{ border: "2px solid rgba(255,255,255,0.4)" }}>
                <Phone size={18} /> 0330 165 8880
              </a>
            </div>
            <p className="text-white/40 text-sm mt-10">
              Looking to join our team? <Link href="/jobs" className="text-white font-bold hover:underline">View open roles →</Link>
            </p>
          </FadeIn>
        </div>
      </section>
    </Layout>
  );
}
