import { useRef, useState } from "react";
import { Link } from "wouter";
import { motion, useInView } from "framer-motion";
import { MapPin, Clock, ArrowRight, AlertCircle, Briefcase, CheckCircle2 } from "lucide-react";
import { useListJobs, useGetJobStats, getListJobsQueryKey, getGetJobStatsQueryKey } from "@workspace/api-client-react";
import { Layout } from "@/components/layout";

const SCRIPT = { fontFamily: "'Dancing Script', cursive" };
const LOCATIONS = ["All Locations", "Plymouth", "Cornwall", "Devon (Various)"];
const TYPES = ["All Types", "full-time", "part-time", "bank"];
const TYPE_LABELS: Record<string, string> = { "full-time": "Full Time", "part-time": "Part Time", "bank": "Bank" };
const PERKS = ["Competitive pay rates", "Paid mileage & travel time", "Full training & induction", "Ongoing professional development", "Supportive management team", "Flexible shift patterns"];

function FadeIn({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-50px" });
  return (
    <motion.div ref={ref} initial={{ opacity: 0, y: 22 }} animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }} className={className}>
      {children}
    </motion.div>
  );
}

export default function Jobs() {
  const [location, setLocation] = useState("");
  const [jobType, setJobType] = useState("");
  const { data: jobs, isLoading } = useListJobs(
    { location: location || undefined, jobType: (jobType as "full-time" | "part-time" | "bank" | "any") || undefined },
    { query: { queryKey: getListJobsQueryKey({ location: location || undefined, jobType: (jobType as "full-time" | "part-time" | "bank" | "any") || undefined }) } }
  );
  const { data: stats } = useGetJobStats({ query: { queryKey: getGetJobStatsQueryKey() } });

  return (
    <Layout>
      {/* Hero — light */}
      <section className="relative overflow-hidden bg-white" style={{ paddingTop: "76px" }}>
        <div className="absolute -top-10 -right-10 w-[400px] h-[400px] rounded-full pointer-events-none"
          style={{ background: "radial-gradient(circle, rgba(239,42,134,0.06) 0%, transparent 70%)" }} />
        <div className="max-w-7xl mx-auto px-5 sm:px-8 pt-16 pb-14">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <p className="text-xs font-bold tracking-widest text-[#EF2A86] uppercase mb-5">Join our team</p>
            <h1 className="text-4xl sm:text-5xl font-bold text-[#05163D] mb-1 leading-tight">A career that</h1>
            <h1 className="text-5xl sm:text-6xl mb-5" style={{ ...SCRIPT, color: "#EF2A86" }}>genuinely matters.</h1>
            <p className="text-gray-500 text-lg max-w-xl leading-relaxed">
              We're always looking for compassionate, dedicated people to join us across Devon &amp; Cornwall. No experience needed for many roles — just the right values.
            </p>
          </motion.div>

          {stats && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
              className="mt-10 flex flex-wrap gap-4">
              <div className="bg-gray-50 border border-gray-100 rounded-2xl px-7 py-4">
                <div className="text-4xl font-bold text-[#05163D]">{stats.totalJobs}</div>
                <div className="text-gray-400 text-xs mt-1 uppercase tracking-wider font-semibold">Open roles</div>
              </div>
              <div className="rounded-2xl px-7 py-4 text-white" style={{ backgroundColor: "#EF2A86", boxShadow: "0 8px 20px rgba(239,42,134,0.3)" }}>
                <div className="text-4xl font-bold">{stats.urgentCount}</div>
                <div className="text-white/70 text-xs mt-1 uppercase tracking-wider font-semibold">Urgent</div>
              </div>
              <div className="bg-gray-50 border border-gray-100 rounded-2xl px-7 py-4">
                <div className="text-4xl font-bold text-[#05163D]">{stats.byLocation.length}</div>
                <div className="text-gray-400 text-xs mt-1 uppercase tracking-wider font-semibold">Locations</div>
              </div>
            </motion.div>
          )}
        </div>
      </section>

      {/* Perks strip */}
      <section className="bg-white border-y border-gray-100">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 py-5">
          <div className="flex flex-wrap gap-x-6 gap-y-2">
            {PERKS.map((p) => (
              <span key={p} className="flex items-center gap-2 text-sm text-gray-500">
                <CheckCircle2 size={13} style={{ color: "#EF2A86" }} className="shrink-0" /> {p}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* Jobs */}
      <section style={{ backgroundColor: "#F4F6FA" }} className="min-h-[60vh] py-12">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <div className="flex flex-col sm:flex-row gap-3 mb-8">
            <select value={location} onChange={(e) => setLocation(e.target.value === "All Locations" ? "" : e.target.value)}
              className="flex-1 sm:flex-none sm:w-52 px-4 py-3 rounded-xl border border-gray-200 bg-white text-sm font-medium text-[#05163D] focus:outline-none focus:ring-2 focus:ring-[#265597] shadow-sm"
              data-testid="filter-location">
              {LOCATIONS.map((l) => <option key={l}>{l}</option>)}
            </select>
            <select value={jobType} onChange={(e) => setJobType(e.target.value === "All Types" ? "" : e.target.value)}
              className="flex-1 sm:flex-none sm:w-52 px-4 py-3 rounded-xl border border-gray-200 bg-white text-sm font-medium text-[#05163D] focus:outline-none focus:ring-2 focus:ring-[#265597] shadow-sm"
              data-testid="filter-job-type">
              {TYPES.map((t) => <option key={t}>{t}</option>)}
            </select>
            {(location || jobType) && (
              <button onClick={() => { setLocation(""); setJobType(""); }}
                className="px-4 py-3 text-sm text-gray-400 hover:text-[#05163D] transition-colors font-medium"
                data-testid="filter-clear">
                Clear filters
              </button>
            )}
            <div className="flex-1" />
            {jobs && <span className="flex items-center text-sm text-gray-400 font-medium">{jobs.length} role{jobs.length !== 1 ? "s" : ""} found</span>}
          </div>

          {isLoading ? (
            <div className="space-y-3">{[...Array(4)].map((_, i) => <div key={i} className="h-24 bg-white rounded-2xl animate-pulse" />)}</div>
          ) : !jobs || jobs.length === 0 ? (
            <div className="text-center py-20 bg-white rounded-3xl">
              <Briefcase size={40} className="mx-auto text-gray-200 mb-4" />
              <h3 className="text-xl font-bold text-[#05163D] mb-2">No roles found</h3>
              <p className="text-gray-400 text-sm">Try adjusting your filters or check back soon.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {jobs.map((job, i) => (
                <motion.div key={job.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}>
                  <Link href={`/jobs/${job.id}`}
                    className="group flex flex-col sm:flex-row sm:items-center gap-4 bg-white rounded-2xl px-6 py-5 hover:shadow-md transition-all border-2 border-transparent hover:border-[#EF2A86]/20"
                    data-testid={`job-row-${job.id}`}>
                    <div className="flex-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2 mb-2">
                        {job.isUrgent && (
                          <span className="inline-flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-full text-white" style={{ backgroundColor: "#EF2A86" }}>
                            <AlertCircle size={10} /> Urgent
                          </span>
                        )}
                        <span className="inline-block text-xs font-semibold px-2.5 py-1 rounded-full bg-gray-100 text-gray-500">{TYPE_LABELS[job.jobType] || job.jobType}</span>
                        <span className="inline-block text-xs font-semibold px-2.5 py-1 rounded-full text-[#265597]" style={{ backgroundColor: "#26559715" }}>{job.category}</span>
                      </div>
                      <h3 className="text-lg font-bold text-[#05163D] group-hover:text-[#265597] transition-colors">{job.title}</h3>
                      <div className="flex flex-wrap items-center gap-4 mt-1.5">
                        <span className="flex items-center gap-1.5 text-sm text-gray-400"><MapPin size={13} /> {job.location}</span>
                        <span className="flex items-center gap-1.5 text-sm text-gray-400"><Clock size={13} /> {job.salaryRange}</span>
                      </div>
                    </div>
                    <span className="hidden sm:inline-flex items-center gap-1.5 text-xs font-bold px-4 py-2 rounded-lg transition-all shrink-0 text-[#EF2A86] group-hover:bg-[#EF2A86] group-hover:text-white"
                      style={{ backgroundColor: "#EF2A8612" }}>
                      Apply <ArrowRight size={12} />
                    </span>
                  </Link>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Bottom CTA — pink */}
      <section className="relative overflow-hidden py-16" style={{ backgroundColor: "#EF2A86" }}>
        <div className="absolute -top-10 right-10 w-52 h-52 rounded-full bg-white opacity-5 pointer-events-none" />
        <div className="relative max-w-3xl mx-auto px-5 sm:px-8 text-center">
          <FadeIn>
            <h2 className="text-3xl font-bold text-white mb-1">Don't see the right role?</h2>
            <h2 className="text-4xl sm:text-5xl text-white mb-5" style={SCRIPT}>Get in touch anyway.</h2>
            <p className="text-white/70 mb-8 leading-relaxed">We're always growing. Send us a message and we'll be in touch when a suitable role comes up.</p>
            <Link href="/contact"
              className="inline-flex items-center gap-2 px-8 py-4 font-bold rounded-xl bg-white hover:scale-105 transition-all"
              style={{ color: "#EF2A86" }}
              data-testid="jobs-contact-cta">
              Get in touch <ArrowRight size={18} />
            </Link>
          </FadeIn>
        </div>
      </section>
    </Layout>
  );
}
