import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { Link } from "wouter";
import { ArrowRight, CheckCircle2, Heart, Users, Star, Award } from "lucide-react";
import { Layout } from "@/components/layout";

const SCRIPT = { fontFamily: "'Dancing Script', cursive" };
const CREAM = "#FDF7F0";

const P124 = "/images/smeaton-124.jpg";
const P131 = "/images/smeaton-131.jpg";
const P108 = "/images/smeaton-108.jpg";

const VALUES = [
  { icon: Star,  name: "Innovation",    desc: "We take risks, encourage curiosity and new ideas, learn from our mistakes, and constantly strive to move forward.", color: "#EF2A86" },
  { icon: Heart, name: "Community",     desc: "We provide a haven of inclusion, trust and support to colleagues, service users, and all stakeholders.", color: "#265597" },
  { icon: Users, name: "Collaboration", desc: "We navigate in partnership — listening to one another and working collaboratively to achieve better outcomes.", color: "#EF2A86" },
  { icon: Award, name: "Excellence",    desc: "We adapt through vigilance and integrity, ensuring every interaction meets the highest standards of care.", color: "#265597" },
  { icon: Star,  name: "Leadership",    desc: "We maintain a culture that empowers colleagues to realise the importance of their contribution.", color: "#EF2A86" },
];

function FadeIn({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-50px" });
  return (
    <motion.div ref={ref} initial={{ opacity: 0, y: 22 }} animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay, ease: [0.22, 1, 0.36, 1] }} className={className}>
      {children}
    </motion.div>
  );
}

export default function About() {
  return (
    <Layout>
      {/* Hero */}
      <section className="relative overflow-hidden bg-white" style={{ paddingTop: "76px" }}>
        <div className="absolute left-0 top-0 bottom-0 w-1.5" style={{ backgroundColor: "#EF2A86" }} />
        <div className="max-w-7xl mx-auto px-8 sm:px-14 pt-16 pb-14">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <p className="text-xs font-bold tracking-widest text-[#EF2A86] uppercase mb-5">Our story</p>
            <h1 className="text-4xl sm:text-5xl font-extrabold text-[#05163D] mb-1 leading-tight tracking-tight">Built on one</h1>
            <div className="mb-5" style={{ ...SCRIPT, fontSize: "clamp(2.5rem, 5.5vw, 4rem)", color: "#EF2A86" }}>simple belief.</div>
            <p className="text-gray-400 text-xl leading-relaxed max-w-2xl">
              That every person deserves care that genuinely respects who they are — delivered by people who chose this work because they care about people, not just a paycheque.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Mission */}
      <section style={{ backgroundColor: CREAM }} className="py-20 sm:py-24">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <FadeIn>
              <div className="relative">
                <div className="aspect-[4/3] rounded-3xl overflow-hidden shadow-2xl">
                  <img src={P124} alt="Smeaton carer and client enjoying garden" className="w-full h-full object-cover" />
                </div>
                <div className="absolute -bottom-5 -right-4 bg-white rounded-2xl px-6 py-5 shadow-2xl border border-gray-100">
                  <div className="text-3xl font-extrabold text-[#05163D] mb-0.5">Since 2019</div>
                  <div className="text-sm text-gray-400">Serving Devon &amp; Cornwall</div>
                </div>
              </div>
            </FadeIn>
            <FadeIn delay={0.1}>
              <p className="text-xs font-bold tracking-widest text-[#EF2A86] uppercase mb-4">Who we are</p>
              <h2 className="text-3xl font-extrabold text-[#05163D] mb-1 tracking-tight">Devon &amp; Cornwall's</h2>
              <div className="mb-6" style={{ ...SCRIPT, fontSize: "clamp(2rem, 4.5vw, 3.5rem)", color: "#EF2A86" }}>trusted homecare provider</div>
              <div className="space-y-4 text-gray-500 leading-relaxed">
                <p>Smeaton Healthcare was founded with a clear purpose: to provide professional, deeply human homecare services to people across Devon &amp; Cornwall. Since 2019, we've grown from a small local team into one of the region's most trusted care providers — with CQC-rated Good offices in both Plymouth and Cornwall.</p>
                <p>We work with elderly people, adults with learning disabilities, those with complex health conditions, and families navigating some of the most difficult moments of their lives.</p>
                <p>Our carers aren't just employees. They're professionals who chose this work because it matters — and we invest heavily in their training, wellbeing, and development.</p>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* Second photo section */}
      <section className="bg-white py-20">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <FadeIn>
              <p className="text-xs font-bold tracking-widest text-[#EF2A86] uppercase mb-4">Our approach</p>
              <h2 className="text-3xl font-extrabold text-[#05163D] mb-1 tracking-tight">Care that feels like</h2>
              <div className="mb-6" style={{ ...SCRIPT, fontSize: "clamp(2rem, 4.5vw, 3.5rem)", color: "#265597" }}>coming home.</div>
              <p className="text-gray-500 leading-relaxed mb-6">
                We believe in consistency. The same carers visiting the same clients builds real relationships — and that's where genuine care happens. Our service users aren't just a name on a schedule; they're people with preferences, routines, and stories that matter to us.
              </p>
              <div className="flex flex-col gap-3">
                {["Matched carers — we consider personalities, not just availability", "Handover notes so every carer knows what matters to you", "Regular reviews to ensure your care plan stays right"].map((item) => (
                  <span key={item} className="flex items-start gap-2 text-sm text-gray-600">
                    <CheckCircle2 size={14} style={{ color: "#EF2A86" }} className="shrink-0 mt-0.5" /> {item}
                  </span>
                ))}
              </div>
            </FadeIn>
            <FadeIn delay={0.1}>
              <div className="aspect-[4/3] rounded-3xl overflow-hidden shadow-xl">
                <img src={P131} alt="Smeaton carer supporting client in garden" className="w-full h-full object-cover" />
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* Accreditations */}
      <section style={{ backgroundColor: CREAM }} className="py-20">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <FadeIn className="mb-12">
            <p className="text-xs font-bold tracking-widest text-[#EF2A86] uppercase mb-3">Trusted &amp; regulated</p>
            <h2 className="text-3xl font-extrabold text-[#05163D] mb-1 tracking-tight">Professional</h2>
            <div style={{ ...SCRIPT, fontSize: "clamp(2rem, 4.5vw, 3.5rem)", color: "#265597" }}>accreditations</div>
          </FadeIn>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {[
              { title: "CQC Rated Good", sub: "Plymouth office", detail: "28 April 2022", color: "#EF2A86" },
              { title: "CQC Rated Good", sub: "Cornwall office", detail: "14 January 2022", color: "#EF2A86" },
              { title: "NHS Approved", sub: "Pre-Qualification Scheme", detail: "Nationally recognised standard", color: "#265597" },
              { title: "Supported Living", sub: "Approved provider", detail: "Accredited framework", color: "#265597" },
            ].map((item, i) => (
              <FadeIn key={i} delay={i * 0.07}>
                <div className="rounded-2xl p-7 h-full bg-white border-2 border-gray-100 hover:border-gray-200 transition-colors">
                  <div className="w-10 h-10 rounded-xl mb-5 flex items-center justify-center" style={{ backgroundColor: item.color }}>
                    <CheckCircle2 size={18} className="text-white" />
                  </div>
                  <h3 className="font-extrabold text-[#05163D] text-lg mb-1">{item.title}</h3>
                  <p className="text-sm text-gray-400 mb-1">{item.sub}</p>
                  <p className="text-xs font-bold" style={{ color: item.color }}>{item.detail}</p>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="bg-white py-20 sm:py-24">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <FadeIn className="mb-14">
            <p className="text-xs font-bold tracking-widest text-[#EF2A86] uppercase mb-3">What drives us</p>
            <h2 className="text-3xl font-extrabold text-[#05163D] mb-1 tracking-tight">The values we</h2>
            <div style={{ ...SCRIPT, fontSize: "clamp(2rem, 4.5vw, 3.5rem)", color: "#265597" }}>work by every day</div>
          </FadeIn>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {VALUES.map((v, i) => {
              const Icon = v.icon;
              return (
                <FadeIn key={i} delay={i * 0.07} className={i === 4 ? "md:col-span-2 lg:col-span-1" : ""}>
                  <div className="rounded-2xl p-7 h-full border-2 border-gray-100 hover:border-gray-200 transition-colors" style={{ backgroundColor: CREAM }}>
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-5" style={{ backgroundColor: v.color }}>
                      <Icon size={18} className="text-white" />
                    </div>
                    <h3 className="text-xl font-extrabold text-[#05163D] mb-3">{v.name}</h3>
                    <p className="text-gray-500 text-sm leading-relaxed">{v.desc}</p>
                  </div>
                </FadeIn>
              );
            })}
          </div>
        </div>
      </section>

      {/* Photo + CTA */}
      <section className="relative overflow-hidden" style={{ minHeight: "400px" }}>
        <div className="absolute inset-0">
          <img src={P108} alt="Smeaton carer with client" className="w-full h-full object-cover object-top" />
          <div className="absolute inset-0" style={{ background: "linear-gradient(to right, rgba(5,22,61,0.88) 0%, rgba(5,22,61,0.5) 50%, transparent 100%)" }} />
        </div>
        <div className="relative max-w-7xl mx-auto px-5 sm:px-8 py-20 flex items-center" style={{ minHeight: "400px" }}>
          <FadeIn className="max-w-xl">
            <h2 className="text-3xl font-extrabold text-white mb-2 tracking-tight">Ready to find out more?</h2>
            <div className="mb-6" style={{ ...SCRIPT, fontSize: "clamp(2rem, 4vw, 3rem)", color: "rgba(239,42,134,0.9)" }}>We'd love to hear from you.</div>
            <p className="text-white/70 mb-8 leading-relaxed">Whether you're looking for care for yourself or a loved one, or thinking about joining our team.</p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/referral"
                className="inline-flex items-center justify-center gap-2 px-7 py-4 text-white font-bold rounded-xl hover:scale-105 transition-all"
                style={{ backgroundColor: "#EF2A86", boxShadow: "0 8px 24px rgba(239,42,134,0.4)" }}
                data-testid="about-referral-cta">
                Request a Free Assessment <ArrowRight size={18} />
              </Link>
              <Link href="/contact"
                className="inline-flex items-center justify-center gap-2 px-7 py-4 font-bold rounded-xl text-white hover:bg-white/10 transition-all"
                style={{ border: "2px solid rgba(255,255,255,0.4)" }}
                data-testid="about-contact-cta">
                Contact us
              </Link>
            </div>
          </FadeIn>
        </div>
      </section>
    </Layout>
  );
}
