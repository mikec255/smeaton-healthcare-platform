import { Link, useParams } from "wouter";
import { motion } from "framer-motion";
import { ArrowRight, CheckCircle2, ArrowLeft } from "lucide-react";
import { Layout } from "@/components/layout";

const SERVICES: Record<string, {
  num: string; name: string; summary: string; intro: string;
  supports: string[]; benefits: string[]; image: string;
}> = {
  "short-visits": {
    num: "01", name: "Short Visits",
    summary: "Flexible care visits from one hour upwards, shaped entirely around your daily routine.",
    intro: "Our short visit service is designed for people who want to maintain their independence at home but need a little extra support at key points of the day. Whether it's help getting ready in the morning, medication reminders, or simply a friendly face for companionship — we build the visit around you, not the other way around.\n\nOur carers are consistent, trusted, and fully trained. You'll get the same carer as often as possible, so they become a genuine part of your routine rather than a stranger at the door.",
    supports: ["Personal Care & Hygiene", "Medication Reminders & Administration", "Meal Preparation", "Household Support", "Shopping & Errands", "Companionship"],
    benefits: ["Visits from 1 hour upwards — no minimum beyond that", "Consistent, trusted carers who know your preferences", "Fully trained, DBS-checked team", "Flexible scheduling — morning, afternoon, or evening", "Regular reviews to adapt as your needs change"],
    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=900&auto=format&fit=crop&q=80",
  },
  "supported-living": {
    num: "02", name: "Supported Living",
    summary: "Helping adults live independently, with the right support for their individual needs.",
    intro: "Supported living is about enabling people — particularly those with learning disabilities, mental health needs, or complex conditions — to live in their own home or a shared house with the support they need to thrive. It's not care in the traditional sense. It's partnership.\n\nOur supported living team works closely with each individual, their families, and relevant professionals to create a support plan that promotes independence, participation in the community, and personal growth.",
    supports: ["Daily Living Skills", "Community Participation & Social Activities", "Personal Care", "Medication Support", "Financial & Administrative Support", "Health Appointments"],
    benefits: ["Person-centred support plans reviewed regularly", "Dedicated keyworker for each individual", "Close working with families and health professionals", "Support to develop skills and independence", "Accredited as a Supported Living Framework Provider"],
    image: "https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?w=900&auto=format&fit=crop&q=80",
  },
  "24-7-care": {
    num: "03", name: "24/7 Care",
    summary: "Round-the-clock specialist care for complex, high-dependency needs.",
    intro: "Some people need care that never switches off. Our 24/7 care service is designed for people with complex health needs, high-dependency conditions, or those who simply cannot be left alone safely. Our team is trained to the highest clinical standards and works in close partnership with NHS professionals.\n\nWhether it's overnight support, live-in care, or a rotating team providing continuous cover, we'll find the right model for your situation and make sure it works — every hour of every day.",
    supports: ["Complex Clinical Care", "Overnight & Waking Night Support", "Live-In Care", "Stoma, Catheter & PEG Care", "Seizure Management", "End-of-Life Care"],
    benefits: ["Highly trained specialist carers", "NHS Approved supplier", "Close co-ordination with clinical teams", "Consistent rota to ensure familiar faces", "24/7 management on-call support"],
    image: "https://images.unsplash.com/photo-1551601651-2a8555f1a136?w=900&auto=format&fit=crop&q=80",
  },
  "enabling": {
    num: "04", name: "Enabling",
    summary: "Building independence rather than creating dependency — care that empowers.",
    intro: "The enabling approach is fundamentally different from traditional care. Instead of doing things for people, we support people to do things for themselves — building skills, confidence, and independence over time.\n\nWe work with people who have the potential to live more independently but need structured support to get there. You might be recovering from an illness, working through a period of difficulty, or simply wanting to build skills you've never had the opportunity to develop. Our enabling team is trained to coach rather than care — and the difference is profound.",
    supports: ["Daily Living Skill Building", "Cooking & Nutrition", "Money Management", "Community Navigation", "Social Skill Development", "Employment Support"],
    benefits: ["Outcome-focused support plans", "Regular progress reviews", "Works towards reduction in support over time", "Links with community resources and activities", "Experienced enabling practitioners"],
    image: "https://images.unsplash.com/photo-1559839914-17aae19cec71?w=900&auto=format&fit=crop&q=80",
  },
  "respite-care": {
    num: "05", name: "Respite Care",
    summary: "Short-term relief for family carers, delivered with warmth and professionalism.",
    intro: "Caring for a loved one is one of the most selfless things a person can do — but it comes at a cost. Exhaustion, stress, and isolation are common among unpaid family carers. Respite care exists to give carers a proper break, knowing their loved one is in safe, experienced hands.\n\nOur respite service is flexible, planned or emergency, and delivered by the same quality team that provides our permanent services. We take the time to understand your loved one's routines, preferences, and needs so that the transition is as smooth and comfortable as possible.",
    supports: ["Planned Respite Breaks", "Emergency & Short-Notice Cover", "Overnight Respite", "Day Sitting", "Hospital-to-Home Support", "Companionship During Carer's Absence"],
    benefits: ["Flexible arrangements — hours to weeks", "Consistent carer allocation where possible", "Full handover from family carers", "Regular updates during placement", "CQC-rated Good for both our offices"],
    image: "https://images.unsplash.com/photo-1491013516836-7db643ee125a?w=900&auto=format&fit=crop&q=80",
  },
};

export default function ServiceDetail() {
  const { slug } = useParams<{ slug: string }>();
  const service = SERVICES[slug ?? ""];

  if (!service) {
    return (
      <Layout>
        <section className="min-h-screen flex items-center justify-center" style={{ backgroundColor: "#05163D" }}>
          <div className="text-center px-5">
            <h1 className="text-3xl font-bold text-white mb-4">Service not found</h1>
            <Link href="/services" className="text-[#EF2A86] font-semibold">View all services →</Link>
          </div>
        </section>
      </Layout>
    );
  }

  return (
    <Layout>
      {/* Hero */}
      <section style={{ backgroundColor: "#05163D" }} className="pt-36 pb-20">
        <div className="max-w-7xl mx-auto px-5 sm:px-8">
          <Link href="/services" className="inline-flex items-center gap-2 text-white/40 hover:text-white text-sm mb-8 transition-colors" data-testid="service-back-link">
            <ArrowLeft size={14} /> All services
          </Link>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <span className="text-6xl font-bold text-white/10">{service.num}</span>
            <h1 className="text-5xl sm:text-6xl font-bold text-white mt-2 mb-5">{service.name}</h1>
            <p className="text-white/60 text-xl max-w-2xl">{service.summary}</p>
          </motion.div>
        </div>
      </section>

      {/* Content */}
      <section className="bg-white">
        <div className="max-w-7xl mx-auto px-5 sm:px-8 py-20">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
            <motion.div initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }}>
              <h2 className="text-2xl font-bold text-[#05163D] mb-6">About this service</h2>
              {service.intro.split("\n\n").map((para, i) => (
                <p key={i} className="text-gray-600 leading-relaxed mb-5">{para}</p>
              ))}

              <h3 className="text-lg font-bold text-[#05163D] mt-10 mb-5">We can support with:</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {service.supports.map((s) => (
                  <div key={s} className="flex items-center gap-3">
                    <CheckCircle2 size={16} className="text-[#EF2A86] shrink-0" />
                    <span className="text-gray-600 text-sm">{s}</span>
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6, delay: 0.1 }}>
              <div className="aspect-[4/3] rounded-3xl overflow-hidden mb-8">
                <img src={service.image} alt={service.name} className="w-full h-full object-cover" />
              </div>

              <div className="rounded-2xl p-8 border border-gray-100">
                <h3 className="text-lg font-bold text-[#05163D] mb-5">Key benefits</h3>
                <ul className="space-y-4">
                  {service.benefits.map((b) => (
                    <li key={b} className="flex items-start gap-3">
                      <div className="w-5 h-5 rounded-full shrink-0 mt-0.5 flex items-center justify-center" style={{ backgroundColor: "#EF2A86" }}>
                        <CheckCircle2 size={11} className="text-white" />
                      </div>
                      <span className="text-gray-600 text-sm leading-relaxed">{b}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{ backgroundColor: "#05163D" }} className="py-20">
        <div className="max-w-3xl mx-auto px-5 sm:px-8 text-center">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-5">Ready to get started?</h2>
          <p className="text-white/60 mb-10">Make a referral today. Our team will arrange a free, no-obligation assessment at a time that suits you.</p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link
              href="/referral"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 text-white font-bold rounded-xl hover:opacity-90 transition-opacity"
              style={{ backgroundColor: "#EF2A86" }}
              data-testid="service-referral-cta"
            >
              Make a Referral <ArrowRight size={18} />
            </Link>
            <a href="tel:03301658880" className="inline-flex items-center justify-center px-8 py-4 font-semibold rounded-xl text-white transition-all" style={{ border: "2px solid rgba(255,255,255,0.3)" }}>
              Call 0330 165 8880
            </a>
          </div>
        </div>
      </section>
    </Layout>
  );
}
