import { useState } from "react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowRight, CheckCircle2, Star } from "lucide-react";
import { Link } from "wouter";
import { useSubmitFeedback } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Layout } from "@/components/layout";

const SERVICES = ["Care at Home", "Supported Living", "24/7 Care", "Enabling", "Respite Care", "Other"];

const schema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  rating: z.number().min(1, "Please select a rating").max(5),
  serviceUsed: z.string().min(1, "Please select a service"),
  comments: z.string().optional(),
});
type FormData = z.infer<typeof schema>;

const inputCls = "w-full px-4 py-3 rounded-xl border border-gray-200 text-sm text-[#05163D] focus:outline-none focus:ring-2 focus:ring-[#265597] transition-shadow bg-white";

function Field({ label, children, error }: { label: string; children: React.ReactNode; error?: string }) {
  return (
    <div>
      <label className="block text-sm font-semibold text-[#05163D] mb-2">{label}</label>
      {children}
      {error && <p className="text-red-500 text-xs mt-1">{error}</p>}
    </div>
  );
}

export default function Feedback() {
  const { toast } = useToast();
  const [submitted, setSubmitted] = useState(false);
  const [hoverRating, setHoverRating] = useState(0);
  const { mutate: submitFeedback, isPending } = useSubmitFeedback();

  const { register, handleSubmit, setValue, watch, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
    mode: "onChange",
    defaultValues: { rating: 0 },
  });

  const rating = watch("rating");

  const onSubmit = (data: FormData) => {
    submitFeedback(
      { data },
      {
        onSuccess: () => setSubmitted(true),
        onError: () => toast({ title: "Something went wrong", description: "Please try again or call us on 0330 165 8880", variant: "destructive" }),
      }
    );
  };

  if (submitted) {
    return (
      <Layout>
        <section className="min-h-screen flex items-center justify-center py-36 px-5" style={{ backgroundColor: "#05163D" }}>
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="text-center max-w-md">
            <div className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6" style={{ backgroundColor: "#EF2A86" }}>
              <CheckCircle2 size={36} className="text-white" />
            </div>
            <h1 className="text-3xl font-bold text-white mb-4">Thank you!</h1>
            <p className="text-white/60 leading-relaxed mb-10">
              Your feedback means a great deal to us. We read every submission and use it to continuously improve our services.
            </p>
            <Link href="/" className="inline-flex items-center gap-2 px-8 py-4 text-white font-bold rounded-xl hover:opacity-90 transition-opacity" style={{ backgroundColor: "#EF2A86" }} data-testid="feedback-success-home-link">
              Back to home <ArrowRight size={18} />
            </Link>
          </motion.div>
        </section>
      </Layout>
    );
  }

  return (
    <Layout>
      <section style={{ backgroundColor: "#05163D" }} className="pt-36 pb-20">
        <div className="max-w-2xl mx-auto px-5 sm:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <div className="flex items-center gap-3 mb-6">
              <div className="h-px w-10 bg-[#EF2A86]" />
              <span className="text-sm font-medium tracking-widest text-white/60 uppercase">Your experience</span>
            </div>
            <h1 className="text-4xl sm:text-5xl font-bold text-white mb-5">Leave Feedback</h1>
            <p className="text-white/60 leading-relaxed">
              Your feedback helps us maintain the highest standards of care and meet CQC requirements. We value every response.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="bg-gray-50 py-16">
        <div className="max-w-2xl mx-auto px-5 sm:px-8">
          <motion.form
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            onSubmit={handleSubmit(onSubmit)}
            className="bg-white rounded-3xl p-8 sm:p-10 space-y-6"
            noValidate
          >
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <Field label="First name" error={errors.firstName?.message}>
                <input {...register("firstName")} className={inputCls} placeholder="Jane" data-testid="feedback-first-name" />
              </Field>
              <Field label="Last name" error={errors.lastName?.message}>
                <input {...register("lastName")} className={inputCls} placeholder="Smith" data-testid="feedback-last-name" />
              </Field>
            </div>

            <Field label="Service used" error={errors.serviceUsed?.message}>
              <select {...register("serviceUsed")} className={inputCls} data-testid="feedback-service">
                <option value="">Select a service...</option>
                {SERVICES.map((s) => <option key={s} value={s}>{s}</option>)}
              </select>
            </Field>

            <Field label="Overall rating" error={errors.rating?.message}>
              <div className="flex items-center gap-2 mt-1" data-testid="feedback-rating">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setValue("rating", star, { shouldValidate: true })}
                    onMouseEnter={() => setHoverRating(star)}
                    onMouseLeave={() => setHoverRating(0)}
                    className="p-1 transition-transform hover:scale-110"
                    data-testid={`rating-star-${star}`}
                  >
                    <Star
                      size={32}
                      fill={(hoverRating || rating) >= star ? "#EF2A86" : "none"}
                      stroke={(hoverRating || rating) >= star ? "#EF2A86" : "#d1d5db"}
                      className="transition-colors"
                    />
                  </button>
                ))}
                {rating > 0 && (
                  <span className="text-sm text-gray-400 ml-2">
                    {["", "Poor", "Fair", "Good", "Very Good", "Excellent"][rating]}
                  </span>
                )}
              </div>
            </Field>

            <Field label="Comments (optional)">
              <textarea
                {...register("comments")}
                rows={5}
                className={inputCls}
                placeholder="Tell us about your experience with Smeaton Healthcare..."
                data-testid="feedback-comments"
              />
            </Field>

            <button
              type="submit"
              disabled={isPending}
              className="w-full py-4 text-white font-bold text-base rounded-xl transition-opacity hover:opacity-90 disabled:opacity-60 flex items-center justify-center gap-2"
              style={{ backgroundColor: "#EF2A86" }}
              data-testid="feedback-submit"
            >
              {isPending ? "Submitting..." : <>Submit Feedback <ArrowRight size={18} /></>}
            </button>
          </motion.form>
        </div>
      </section>
    </Layout>
  );
}
