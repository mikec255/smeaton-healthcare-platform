import { Link } from "wouter";
import { Layout } from "@/components/layout";

export default function NotFound() {
  return (
    <Layout>
      <section className="min-h-screen flex items-center justify-center" style={{ backgroundColor: "#05163D" }}>
        <div className="text-center px-5">
          <div className="text-[140px] font-bold text-white/10 leading-none">404</div>
          <h1 className="text-3xl font-bold text-white mt-4">Page not found</h1>
          <p className="text-white/60 mt-3 mb-8">This page doesn't exist or has been moved.</p>
          <Link href="/" className="inline-block px-8 py-4 text-white font-semibold rounded-xl" style={{ backgroundColor: "#EF2A86" }}>
            Go home
          </Link>
        </div>
      </section>
    </Layout>
  );
}
