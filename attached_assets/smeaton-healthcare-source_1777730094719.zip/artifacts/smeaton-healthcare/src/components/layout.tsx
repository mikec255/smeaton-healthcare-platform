import { useState, useEffect, useRef } from "react";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { X, Menu, Phone, ChevronDown, ArrowRight } from "lucide-react";

const SERVICES_MENU = [
  {
    href: "/services/short-visits",
    name: "Short Visits",
    desc: "Flexible care visits from one hour upwards, built around your daily routine.",
    img: "/images/smeaton-108.jpg",
  },
  {
    href: "/services/supported-living",
    name: "Supported Living",
    desc: "Helping adults live independently with exactly the right level of support.",
    img: "/images/smeaton-131.jpg",
  },
  {
    href: "/services/24-7-care",
    name: "24/7 Care",
    desc: "Round-the-clock care for people with complex, high-dependency needs.",
    img: "/images/smeaton-117.jpg",
  },
  {
    href: "/services/enabling",
    name: "Enabling",
    desc: "Building independence, not dependency — helping people achieve their own goals.",
    img: "/images/smeaton-124.jpg",
  },
  {
    href: "/services/respite-care",
    name: "Respite Care",
    desc: "Short-term relief for family carers, delivered by our trusted team.",
    img: "/images/smeaton-131.jpg",
  },
];

const OTHER_NAV = [
  { href: "/about", label: "About Us" },
  { href: "/jobs", label: "Careers" },
  { href: "/contact", label: "Contact" },
];

export function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [servicesOpen, setServicesOpen] = useState(false);
  const [location] = useLocation();
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setMobileOpen(false);
    setServicesOpen(false);
  }, [location]);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setServicesOpen(false);
      }
    }
    if (servicesOpen) document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [servicesOpen]);

  return (
    <>
      <header
        className="fixed left-0 right-0 top-0 z-40"
        style={{ backgroundColor: "white", boxShadow: "0 1px 0 rgba(0,0,0,0.07)" }}
        ref={dropdownRef}
      >
        <div className="px-12 sm:px-20 h-[80px] sm:h-[96px] flex items-center justify-between gap-8">

          {/* LEFT — logo */}
          <Link href="/" data-testid="nav-logo" className="shrink-0">
            <img
              src="https://www.smeatonhealthcare.co.uk/assets/logo-B4_I79mo.png"
              alt="Smeaton Healthcare"
              style={{ width: "185px", height: "auto" }}
            />
          </Link>

          {/* RIGHT — nav links + phone + CTA */}
          <div className="hidden lg:flex items-center gap-7 ml-auto">

            {/* Our Services — mega dropdown trigger */}
            <button
              onClick={() => setServicesOpen(!servicesOpen)}
              className="flex items-center gap-1 text-sm font-semibold transition-colors duration-200"
              style={{ color: servicesOpen ? "#EF2A86" : "#05163D" }}
              data-testid="nav-services-trigger"
            >
              Our Services
              <motion.span animate={{ rotate: servicesOpen ? 180 : 0 }} transition={{ duration: 0.2 }}>
                <ChevronDown size={14} strokeWidth={2.5} />
              </motion.span>
            </button>

            {OTHER_NAV.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className="text-sm font-semibold text-[#05163D] hover:text-[#EF2A86] transition-colors duration-200"
                data-testid={`nav-${l.label.split(" ")[0].toLowerCase()}`}
              >
                {l.label}
              </Link>
            ))}

            <a
              href="tel:03301658880"
              className="text-sm font-bold flex items-center gap-1.5 hover:text-[#EF2A86] transition-colors"
              style={{ color: "#265597" }}
            >
              <Phone size={14} />
              0330 165 8880
            </a>
            <Link
              href="/referral"
              className="px-5 py-2.5 text-sm font-bold rounded-lg text-white transition-all hover:opacity-90 hover:scale-105"
              style={{ backgroundColor: "#EF2A86", boxShadow: "0 4px 16px rgba(239,42,134,0.35)" }}
              data-testid="nav-referral-cta"
            >
              Free Assessment
            </Link>
          </div>

          {/* Mobile toggle */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="lg:hidden p-2 text-[#05163D]"
            aria-label="Toggle menu"
            data-testid="mobile-menu-toggle"
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mega dropdown panel */}
        <AnimatePresence>
          {servicesOpen && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.22, ease: "easeOut" }}
              className="absolute left-0 right-0 border-t"
              style={{
                backgroundColor: "white",
                borderColor: "rgba(0,0,0,0.06)",
                boxShadow: "0 24px 48px rgba(5,22,61,0.14)",
              }}
            >
              <div className="max-w-7xl mx-auto px-12 sm:px-20 py-10 flex gap-12">

                {/* Left intro column */}
                <div className="w-56 shrink-0 flex flex-col justify-between">
                  <div>
                    <p className="text-xs font-bold tracking-widest uppercase mb-3" style={{ color: "#EF2A86" }}>
                      Our Services
                    </p>
                    <h3 className="text-xl font-extrabold leading-snug mb-3" style={{ color: "#05163D" }}>
                      Care that fits your life
                    </h3>
                    <p className="text-sm text-gray-500 leading-relaxed">
                      Five specialist services, designed around the individual — not a one-size-fits-all package.
                    </p>
                  </div>
                  <Link
                    href="/services"
                    className="inline-flex items-center gap-1.5 text-sm font-bold mt-8 hover:gap-2.5 transition-all"
                    style={{ color: "#EF2A86" }}
                  >
                    View all services <ArrowRight size={14} />
                  </Link>
                </div>

                {/* Divider */}
                <div className="w-px shrink-0" style={{ backgroundColor: "rgba(0,0,0,0.07)" }} />

                {/* Service cards grid */}
                <div className="flex-1 grid grid-cols-3 gap-5">
                  {SERVICES_MENU.map((s, i) => (
                    <Link
                      key={s.href}
                      href={s.href}
                      className="group flex flex-col rounded-xl overflow-hidden border hover:border-[#EF2A86] transition-all duration-200"
                      style={{ borderColor: "rgba(0,0,0,0.08)" }}
                    >
                      <div className="relative overflow-hidden" style={{ height: "110px" }}>
                        <img
                          src={s.img}
                          alt={s.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <div
                          className="absolute inset-0"
                          style={{ background: "linear-gradient(to top, rgba(5,22,61,0.35) 0%, transparent 60%)" }}
                        />
                      </div>
                      <div className="p-4 flex flex-col gap-1.5 flex-1">
                        <p className="text-sm font-bold" style={{ color: i % 2 === 0 ? "#EF2A86" : "#265597" }}>
                          {s.name}
                        </p>
                        <p className="text-xs text-gray-500 leading-relaxed">{s.desc}</p>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Mobile drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            className="fixed inset-0 z-40 flex flex-col"
            style={{ backgroundColor: "#05163D" }}
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "tween", duration: 0.3, ease: "easeInOut" }}
          >
            <div className="flex items-center justify-between px-5 h-[72px] sm:h-[84px] border-b border-white/10">
              <img
                src="https://www.smeatonhealthcare.co.uk/assets/logo-B4_I79mo.png"
                alt="Smeaton Healthcare"
                className="h-12 w-auto"
                style={{ filter: "brightness(0) invert(1)" }}
              />
              <button onClick={() => setMobileOpen(false)} className="p-2 text-white" aria-label="Close menu">
                <X size={24} />
              </button>
            </div>
            <div className="flex-1 flex flex-col justify-center px-8">
              <div className="space-y-1">
                <Link href="/" className="block text-3xl font-bold text-white py-4 border-b border-white/10 hover:text-[#EF2A86] transition-colors" data-testid="mobile-nav-home">Home</Link>
                <Link href="/services" className="block text-3xl font-bold text-white py-4 border-b border-white/10 hover:text-[#EF2A86] transition-colors" data-testid="mobile-nav-our">Our Services</Link>
                {OTHER_NAV.map((l) => (
                  <Link
                    key={l.href}
                    href={l.href}
                    className="block text-3xl font-bold text-white py-4 border-b border-white/10 hover:text-[#EF2A86] transition-colors"
                    data-testid={`mobile-nav-${l.label.split(" ")[0].toLowerCase()}`}
                  >
                    {l.label}
                  </Link>
                ))}
              </div>
              <div className="mt-10 flex flex-col gap-4">
                <Link
                  href="/referral"
                  className="w-full py-4 text-center text-lg font-bold text-white rounded-xl"
                  style={{ backgroundColor: "#EF2A86" }}
                  data-testid="mobile-nav-referral"
                >
                  Request a Free Assessment
                </Link>
                <a href="tel:03301658880" className="flex items-center justify-center gap-2 py-3 text-white/60 text-base">
                  <Phone size={16} /> 0330 165 8880
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}

export function Footer() {
  return (
    <footer style={{ backgroundColor: "#05163D" }} className="text-white">
      <div className="max-w-7xl mx-auto px-5 sm:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          <div className="lg:col-span-2">
            <img
              src="https://www.smeatonhealthcare.co.uk/assets/logo-B4_I79mo.png"
              alt="Smeaton Healthcare"
              className="h-12 w-auto mb-4"
              style={{ filter: "brightness(0) invert(1)" }}
            />
            <p className="text-white/60 text-sm leading-relaxed max-w-xs mb-5">
              Home care you can trust, delivered by people who care — across Devon &amp; Cornwall since 2019.
            </p>
            <a href="tel:03301658880" className="inline-flex items-center gap-2 text-white font-bold text-base hover:text-[#EF2A86] transition-colors">
              <Phone size={16} /> 0330 165 8880
            </a>
          </div>

          <div>
            <p className="text-xs font-bold tracking-widest text-white/30 uppercase mb-4">Services</p>
            <ul className="space-y-2.5">
              {[
                { href: "/services/short-visits", label: "Short Visits" },
                { href: "/services/supported-living", label: "Supported Living" },
                { href: "/services/24-7-care", label: "24/7 Care" },
                { href: "/services/enabling", label: "Enabling" },
                { href: "/services/respite-care", label: "Respite Care" },
              ].map((s) => (
                <li key={s.href}><Link href={s.href} className="text-white/50 hover:text-white text-sm transition-colors">{s.label}</Link></li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-xs font-bold tracking-widest text-white/30 uppercase mb-4">Company</p>
            <ul className="space-y-2.5">
              {[
                { href: "/about", label: "About Us" },
                { href: "/referral", label: "Request Care" },
                { href: "/jobs", label: "Careers" },
                { href: "/feedback", label: "Leave Feedback" },
                { href: "/contact", label: "Contact" },
              ].map((l) => (
                <li key={l.href}><Link href={l.href} className="text-white/50 hover:text-white text-sm transition-colors">{l.label}</Link></li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-white/10 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <p className="text-white/30 text-sm">© {new Date().getFullYear()} Smeaton Healthcare Ltd. All rights reserved.</p>
          <p className="text-white/30 text-xs">CQC Rated Good — Plymouth (April 2022) &amp; Cornwall (January 2022)</p>
        </div>
      </div>
    </footer>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Navbar />
      <main>{children}</main>
      <Footer />
    </>
  );
}
